async function sendToDiscord(message) {
  try {
    const result = await chrome.storage.sync.get(["webhooks", "activeWebhook"]);
    const webhooks = result.webhooks || [];
    const activeWebhookName = result.activeWebhook;
    const webhook = webhooks.find((w) => w.name === activeWebhookName);

    if (!webhook) {
      throw new Error("Active webhook not found");
    }

    const response = await fetch(webhook.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        avatar_url: "https://i.imgur.com/xi6Qssm.png",
        content: message,
      }),
    });

    if (response.ok) {
      console.log("Message sent to Discord");
      return "Message sent";
    } else {
      console.error("Error sending message to Discord:", response.statusText);
      return "Error";
    }
  } catch (error) {
    console.error("Error:", error);
    return "Error";
  }
}

function handleSendToDiscord(request, sendResponse) {
  sendToDiscord(request.message)
    .then((result) => {
      sendResponse({ status: result === "Message sent" ? "ok" : "error" });
    })
    .catch((error) => {
      sendResponse({ status: "error", message: error.message });
    });
}

// Function to parse dice history and format message
function parseDiceHistory(history, title) {
  // console.log('parseDiceHistory', history)
  history = removePrefix(history);
  // console.log('removePrefix', history)
  history = stripHTML(history);
  // const generalRegex = /(\w+): (\d+)(?: (\d+) d\d+ \+(\d+))?/;
  // const match = generalRegex.exec(history);
  const match = history.split(" ");
  // console.log('match', match)

  if (match) {
    const rollType = match[0];
    const rollValue = match[2];

    if (rollType === "Critical") {
      return `Critical Hit! **${characterName}'s** ${title} caused **${rollValue}** damage.`;
    } else if (rollType === "Attack") {
      return `**${characterName}'s** ${title} attempts to hit with a **${rollValue}**.`;
    } else if (rollType === "Damage") {
      return `**${characterName}'s** ${title} caused **${rollValue}** damage.`;
    } else {
      return `**${characterName}** rolls ${title} for **${match[1]}**.`;
    }
  }

  return `${stripHTML(history)}`;
}

// Function to strip HTML tags and replace them with spaces
function stripHTML(html) {
  return html.replace(/<\/?[^>]+(>|$)/g, " ");
}

// Function to remove "Dice history: TIME Your" part and replace with character name
function removePrefix(history) {
  return history.replace(/\d{1,2}:\d{2}:\d{2} (AM|PM) Your /, ``);
}

function handleLogDiceHistory(request, sendResponse) {
  if (characterName) {
    const formattedMessage = parseDiceHistory(request.data, request.title);
    sendToDiscord(formattedMessage)
      .then((result) => {
        sendResponse({ status: result === "Message sent" ? "ok" : "error" });
      })
      .catch((error) => {
        sendResponse({ status: "error", message: error.message });
      });
  } else {
    chrome.runtime.sendMessage({
      action: "getCharacterName",
      history: request.data,
    });
  }
}

function handleLogCharacterName(request, sendResponse) {
  characterName = request.data;
  const formattedMessage = parseDiceHistory(request.history, request.title);
  sendToDiscord(formattedMessage)
    .then((result) => {
      sendResponse({ status: result === "Message sent" ? "ok" : "error" });
    })
    .catch((error) => {
      sendResponse({ status: "error", message: error.message });
    });
}

function handleLogDetails(request, sendResponse) {
  const message = `${request.data}`;
  sendToDiscord(message)
    .then((result) => {
      sendResponse({ status: result === "Message sent" ? "ok" : "error" });
    })
    .catch((error) => {
      sendResponse({ status: "error", message: error.message });
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case "logDiceHistory":
      handleLogDiceHistory(request, sendResponse);
      break;
    case "logCharacterName":
      handleLogCharacterName(request, sendResponse);
      break;
    case "logListViewDetails":
      handleLogDetails(request, sendResponse);
      break;
    case "sendToDiscord":
      handleSendToDiscord(request, sendResponse);
      break;
    default:
      console.error("Unknown action:", request.action);
      break;
  }
  return true; // Keep the message channel open for async response
});
