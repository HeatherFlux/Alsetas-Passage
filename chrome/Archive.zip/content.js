const browser = chrome;

// Ensure toast.js and toast.css are included
const css = document.createElement("link");
css.href = browser.runtime.getURL("toast.css");
css.rel = "stylesheet";
document.head.appendChild(css);

const script = document.createElement("script");
script.src = browser.runtime.getURL("toast.js");
document.head.appendChild(script);

// Function to show toast notification
function showToast(message, duration = 3000) {
  // Ensure the toast container exists
  let toastContainer = document.getElementById("toast-container");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.id = "toast-container";
    document.body.appendChild(toastContainer);
  }

  // Create the toast element
  const toast = document.createElement("div");
  toast.className = "toast";

  // Create the message text node
  const messageNode = document.createTextNode(message);
  toast.appendChild(messageNode);

  // Create the close button
  const closeButton = document.createElement("span");
  closeButton.className = "close-btn";
  closeButton.textContent = "×";
  closeButton.addEventListener("click", () => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 500);
  });

  toast.appendChild(closeButton);

  // Append the toast to the container
  toastContainer.appendChild(toast);

  // Show the toast
  setTimeout(() => toast.classList.add("show"), 10);

  // Remove the toast after the specified duration
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 500);
  }, duration);
}

// Event listener registry
const eventListenerRegistry = new WeakMap();

// Function to format listview details
function formatListViewDetails(details) {
  return details.replace(/\n+/g, "\n> ").trim();
}

// Function to convert HTML to Markdown
function convertHtmlToMarkdown(htmlContent) {
  let markdown = htmlContent;

  // Replace bold tags with **
  markdown = markdown.replace(/<b>(.*?)<\/b>/g, "**$1**");

  // Replace italic tags with *
  markdown = markdown.replace(/<i>(.*?)<\/i>/g, "*$1*");

  // Replace line breaks with new lines
  markdown = markdown.replace(/<br\s*\/?>/g, "\n");

  // Remove any remaining HTML tags
  markdown = markdown.replace(/<[^>]+>/g, "\n");

  return markdown.trim();
}

// Function to create the export button
function createExportButton() {
  const button = document.createElement("button");
  button.textContent = "Send To Discord";
  button.className = "discord-export-button";
  button.style.fontSize = "12px"; // Make the font smaller
  button.style.marginBottom = "10px"; // Add some margin for spacing
  button.style.padding = "2px 5px"; // Adjust padding for a smaller button
  button.style.display = "inline-block"; // Ensure the button is inline
  button.style.verticalAlign = "middle"; // Align button vertically
  button.style.backgroundColor = "#4CAF50"; // Background color for button
  button.style.color = "white"; // Text color for button
  button.style.border = "none"; // Remove border
  button.style.borderRadius = "4px"; // Rounded corners
  button.style.cursor = "pointer"; // Pointer cursor on hover
  button.style.width = "auto"; // Make sure the button is not wide
  return button;
}

// Function to extract and format traits
function extractAndFormatTraits(detailDiv) {
  const traitDivs = detailDiv.querySelectorAll(".trait");
  const traits = Array.from(
    new Set(Array.from(traitDivs).map((trait) => `**${trait.innerText}**`))
  ).join(" ");
  return { traits, traitDivs };
}

// Function to remove elements from HTML content
function removeElementsFromHtml(contentHtml, elements) {
  elements.forEach((element) => {
    contentHtml = contentHtml.replace(element.outerHTML, "");
  });
  return contentHtml;
}

// Function to prepare the message to send to Discord
function prepareMessage(title, traits, contentMarkdown) {
  const formattedDetails = formatListViewDetails(contentMarkdown);
  return traits
    ? `**${title}**\n> **Traits:** ${traits}\n> ${formattedDetails}`
    : `**${title}**\n> ${formattedDetails}`;
}

// Function to handle button click event
function handleButtonClick(event, div) {
  // console.log("Button Clicked:", div);
  event.stopPropagation(); // Prevent the click from propagating to parent divs

  let detailDiv = div.querySelector(".listview-detail");
  if (!detailDiv || detailDiv.innerHTML.trim() === "") {
    detailDiv = detailDiv.nextElementSibling;
  }
  if (!detailDiv) {
    console.error("No detailDiv found for", div);
    return;
  }

  // Get the title
  const titleDiv = div.querySelector(".listview-title");
  const title = titleDiv ? titleDiv.innerText : "";
  // console.log("Title:", title);

  // Extract and format traits
  const { traits, traitDivs } = extractAndFormatTraits(detailDiv);
  // console.log("Traits:", traits);

  // Get the remaining content without the button and traits
  let contentHtml = detailDiv.innerHTML;
  contentHtml = removeElementsFromHtml(contentHtml, traitDivs);
  const button = div.querySelector(".discord-export-button");
  if (button) {
    contentHtml = removeElementsFromHtml(contentHtml, [button]);
  }

  const contentMarkdown = convertHtmlToMarkdown(contentHtml);
  const message = prepareMessage(title, traits, contentMarkdown);

  // console.log("Detail export button clicked for:", detailDiv);
  // // console.log("Message to send:", message);

  // Send message to background script to send to Discord
  browser.runtime
    .sendMessage({
      action: "sendToDiscord",
      message: message,
    })
    .then((response) => {
      if (response && response.status === "ok") {
        console.log("Message sent to background script");
        // No action needed on success
      } else {
        showToast("Error going to Discord");
        console.error("Failed to send message to background script");
      }
    })
    .catch((error) => {
      showToast("Error going to Discord");
      console.error("Error sending message to background script:", error);
    });
}

// Function to check if the button already has an event listener
function hasEventListener(element, eventName) {
  return (
    eventListenerRegistry.has(element) &&
    eventListenerRegistry.get(element).includes(eventName)
  );
}

// Function to add a detail export button to a div
function addDetailExportButton(div) {
  let detailDiv = div.querySelector(".listview-detail");
  if (detailDiv && detailDiv.innerHTML.trim() === "") {
    detailDiv = detailDiv.nextElementSibling;
  }

  if (detailDiv) {
    let button = detailDiv.querySelector(".discord-export-button");
    if (button && hasEventListener(button, "click")) {
      // console.log("Button with event listener already exists for", detailDiv);
      return;
    }

    if (!button) {
      button = createExportButton();
      detailDiv.insertBefore(button, detailDiv.firstChild);
      // console.log("Created and added button to", detailDiv);
    }

    if (!hasEventListener(button, "click")) {
      button.addEventListener("click", (event) =>
        handleButtonClick(event, div)
      );

      // Update event listener registry
      if (!eventListenerRegistry.has(button)) {
        eventListenerRegistry.set(button, []);
      }
      eventListenerRegistry.get(button).push("click");

      // console.log("Attached event listener to button for", detailDiv);
    }
  }
}

// Function to handle dynamically loaded content and attach buttons
function handleDynamicContent() {
  const containers = document.querySelectorAll(
    ".listview-item, .div-info-lm-box"
  );
  containers.forEach((div) => {
    addDetailExportButton(div);

    // Add click event listener to reveal hidden details and reattach button if needed
    div.addEventListener("click", () => {
      setTimeout(() => {
        let hiddenDetailDiv = div.querySelector(".listview-detail.hidden");
        if (hiddenDetailDiv && hiddenDetailDiv.innerHTML.trim() === "") {
          hiddenDetailDiv = hiddenDetailDiv.nextElementSibling;
        }
        if (hiddenDetailDiv) {
          hiddenDetailDiv.classList.remove("hidden");
          addDetailExportButton(div);
        }
      }, 500); // Adjust the timeout as needed
    });
  });
}

// Observe the document for added nodes
const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    mutation.addedNodes.forEach((node) => {
      if (node.nodeType === 1) {
        // Ensure it's an element node
        if (node.matches(".listview-item, .div-info-lm-box")) {
          addDetailExportButton(node);
          node.addEventListener("click", () => {
            setTimeout(() => {
              let detailDiv = node.querySelector(".listview-detail");
              if (detailDiv && detailDiv.innerHTML.trim() === "") {
                detailDiv = detailDiv.nextElementSibling;
              }
              if (detailDiv && !detailDiv.classList.contains("hidden")) {
                // console.log("Detail content If:", detailDiv.innerHTML);
              }
            }, 500); // Adjust the timeout as needed
          });
        } else {
          // Check for any child .listview-item elements in the newly added node
          node
            .querySelectorAll(".listview-item, .div-info-lm-box")
            .forEach((child) => {
              addDetailExportButton(child);
              child.addEventListener("click", () => {
                setTimeout(() => {
                  let detailDiv = child.querySelector(".listview-detail");
                  if (detailDiv && detailDiv.innerHTML.trim() === "") {
                    detailDiv = detailDiv.nextElementSibling;
                  }
                  if (detailDiv && !detailDiv.classList.contains("hidden")) {
                    // console.log("Detail content Else:", detailDiv.innerHTML);
                  }
                }, 500); // Adjust the timeout as needed
              });
            });
        }
      }
    });
  });
});

// Start observing the body for added child nodes
observer.observe(document.body, { childList: true, subtree: true });

// Initial call to add buttons to already existing items
document.addEventListener("DOMContentLoaded", () => {
  // console.log("DOM fully loaded and parsed");
  handleDynamicContent();
});

let characterName = "";
let diceTitle = "";

// Function to fetch the character name
function fetchCharacterName() {
  const characterNameDiv = Array.from(
    document.querySelectorAll(".small-text.grey-text.button-text")
  ).find((div) => div.textContent.trim() === "Character Name");
  if (characterNameDiv) {
    const nextSiblingDiv = characterNameDiv.nextElementSibling;
    if (
      nextSiblingDiv &&
      nextSiblingDiv.classList.contains("button-selection")
    ) {
      return nextSiblingDiv.textContent;
    }
  }
  return null;
}

// Function to fetch the dice title
function fetchDiceTitle() {
  const diceTitleDiv = document.getElementById("dice-title");
  if (diceTitleDiv) {
    return diceTitleDiv.textContent;
  }
  return "";
}

// Function to log the latest dice history
function logDiceHistory() {
  const diceHistoryDiv = document.getElementById("dice-history");
  if (diceHistoryDiv) {
    const latestHistory = diceHistoryDiv.firstElementChild;
    if (latestHistory) {
      // console.log(`Dice history: ${latestHistory.innerHTML}`);
      diceTitle = fetchDiceTitle(); // Fetch dice title each time history is logged
      if (characterName) {
        browser.runtime.sendMessage({
          action: "logDiceHistory",
          data: latestHistory.innerHTML,
          title: diceTitle, // Include dice title in the message
        });
      } else {
        const name = fetchCharacterName();
        if (name) {
          characterName = name;
          browser.runtime.sendMessage({
            action: "logCharacterName",
            data: name,
            history: latestHistory.innerHTML,
            title: diceTitle, // Include dice title in the message
          });
        }
      }
    }
  } else {
    // console.log("Dice history div not found");
  }
}

// Function to format listview details
function formatListViewDetails(details) {
  // console.log(details);
  let formattedDetails = details.replace(/\n+/g, "\n> ").trim();
  return formattedDetails;
}

// Function to log listview details
function logListViewDetails() {
  const listViewTitle = document.querySelector(
    ".listview-item.div-info-lm-box .listview-title"
  );
  const listViewDetails = document.querySelector(
    ".listview-item.div-info-lm-box .listview-detail"
  );

  if (listViewTitle && listViewDetails) {
    const titleText = listViewTitle.innerText;
    const detailsText = listViewDetails.innerText;

    const traits = Array.from(
      listViewDetails.querySelectorAll(".trait.trait-common")
    )
      .map((trait) => `**${trait.innerText}**`)
      .join(" ");

    const formattedDetails = formatListViewDetails(detailsText);
    const message = `**${titleText}**\n> *${traits}*\n> ${formattedDetails}`;

    // console.log(`ListView Details: ${message}`);
    browser.runtime.sendMessage({
      action: "logListViewDetails",
      data: message,
    });
  } else {
    // console.log("ListView details not found");
  }
}

// Observe changes in the dice history div
function observeDiceHistory() {
  const diceHistoryDiv = document.getElementById("dice-history");
  if (diceHistoryDiv) {
    const observer = new MutationObserver(() => {
      logDiceHistory();
    });

    observer.observe(diceHistoryDiv, { childList: true });
  } else {
    // console.log("Dice history div not found");
  }
}

// Observe changes in the sidebar to fetch the title
function observeSidebar() {
  const sidebar = document.querySelector(".dice-tray"); // Correct sidebar selector
  if (sidebar) {
    const observer = new MutationObserver(() => {
      diceTitle = fetchDiceTitle();
      // console.log(`Dice title updated: ${diceTitle}`);
    });

    observer.observe(sidebar, { childList: true, subtree: true });
  } else {
    // console.log("Sidebar not found");
  }
}

// Initialize the script
function init() {
  observeDiceHistory();
  observeSidebar(); // Add sidebar observation
}

// Run init on page load
window.addEventListener("load", init);
